package com.example.gogo;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class CultureSectionActivity extends AppCompatActivity {

    private TextView sectionTitleTextView;
    private TextView sectionDescriptionTextView;
    private TextView detailTextView;
    private ImageView sectionImageView;
    private Button favoriteButton;
    private Button nextButton;
    private Button prevButton;
    private Button backButton;

    private String currentSection;
    private int currentItemIndex = 0;

    private static class CultureItem {
        String title;
        String description;
        int imageResource;

        CultureItem(String title, String description, int imageResource) {
            this.title = title;
            this.description = description;
            this.imageResource = imageResource;
        }
    }

    private final CultureItem[][] cultureData = {
            {
                    new CultureItem("Александр Пушкин", "Величайший русский поэт", R.drawable.ic_launcher_foreground),
                    new CultureItem("Фёдор Достоевский", "Классик мировой литературы", R.drawable.ic_launcher_foreground),
                    new CultureItem("Лев Толстой", "Автор «Войны и мира»", R.drawable.ic_launcher_foreground)
            },
            {
                    new CultureItem("Пётр Чайковский", "Великий русский композитор", R.drawable.ic_launcher_foreground),
                    new CultureItem("Модест Мусоргский", "Композитор, автор оперы «Борис Годунов»", R.drawable.ic_launcher_foreground),
                    new CultureItem("Сергей Рахманинов", "Композитор и пианист", R.drawable.ic_launcher_foreground)
            },
            {
                    new CultureItem("Илья Репин", "Художник-передвижник", R.drawable.ic_launcher_foreground),
                    new CultureItem("Василий Кандинский", "Основоположник абстрактного искусства", R.drawable.ic_launcher_foreground),
                    new CultureItem("Иван Айвазовский", "Маринист, автор «Девятого вала»", R.drawable.ic_launcher_foreground)
            },
            {
                    new CultureItem("Храм Василия Блаженного", "Символ Москвы на Красной площади", R.drawable.ic_launcher_foreground),
                    new CultureItem("Зимний дворец", "Резиденция российских императоров", R.drawable.ic_launcher_foreground),
                    new CultureItem("Собор Василия Блаженного", "Православный храм на Красной площади", R.drawable.ic_launcher_foreground)
            },
            {
                    new CultureItem("Масленица", "Славянский праздник проводов зимы", R.drawable.ic_launcher_foreground),
                    new CultureItem("Самовар", "Традиционный русский сосуд для кипячения воды", R.drawable.ic_launcher_foreground),
                    new CultureItem("Матрешка", "Русская деревянная игрушка", R.drawable.ic_launcher_foreground)
            }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_culture_section);

        sectionTitleTextView = findViewById(R.id.sectionTitleTextView);
        sectionDescriptionTextView = findViewById(R.id.sectionDescriptionTextView);
        detailTextView = findViewById(R.id.detailTextView);
        sectionImageView = findViewById(R.id.sectionImageView);
        favoriteButton = findViewById(R.id.favoriteButton);
        nextButton = findViewById(R.id.nextButton);
        prevButton = findViewById(R.id.prevButton);
        backButton = findViewById(R.id.backButton);

        currentSection = getIntent().getStringExtra("section");
        if (currentSection == null) {
            currentSection = "literature";
        }

        favoriteButton.setOnClickListener(v -> toggleFavorite());
        nextButton.setOnClickListener(v -> nextItem());
        prevButton.setOnClickListener(v -> prevItem());
        backButton.setOnClickListener(v -> finish());

        loadSectionData();
    }

    private void loadSectionData() {
        int sectionIndex = getSectionIndex(currentSection);
        if (sectionIndex >= 0 && currentItemIndex < cultureData[sectionIndex].length) {
            CultureItem item = cultureData[sectionIndex][currentItemIndex];

            sectionTitleTextView.setText(item.title);
            sectionDescriptionTextView.setText(item.description);
            detailTextView.setText(getDetailInfo(sectionIndex, currentItemIndex));
            sectionImageView.setImageResource(item.imageResource);

            updateNavigationButtons(sectionIndex);
            updateFavoriteButton();
        }
    }

    private int getSectionIndex(String section) {
        switch (section) {
            case "literature": return 0;
            case "music": return 1;
            case "art": return 2;
            case "architecture": return 3;
            case "traditions": return 4;
            default: return -1;
        }
    }

    private String getDetailInfo(int sectionIndex, int itemIndex) {
        String[][] details = {
                {"1799-1837 гг. Автор «Евгения Онегина»", "1821-1881 гг. Автор «Идиота»", "1828-1910 гг. Автор «Анны Карениной»"},
                {"1840-1893 гг. Создатель классической музыки", "1839-1881 гг. Новатор в музыке", "1873-1943 гг. Выдающийся пианист"},
                {"1844-1930 гг. Ключевая фигура реализма", "1866-1944 гг. Теоретик искусства", "1817-1900 гг. Мастер морских пейзажей"},
                {"1555-1561 гг. Построен Иваном Грозным", "1754-1762 гг. Архитектор Растрелли", "1555-1561 гг. Памятник архитектуры"},
                {"Празднуется за 7 недель до Пасхи", "Появился в XVIII веке", "Появилась в конце XIX века"}
        };

        return details[sectionIndex][itemIndex];
    }

    private void nextItem() {
        int sectionIndex = getSectionIndex(currentSection);
        if (currentItemIndex < cultureData[sectionIndex].length - 1) {
            currentItemIndex++;
            loadSectionData();
        }
    }

    private void prevItem() {
        if (currentItemIndex > 0) {
            currentItemIndex--;
            loadSectionData();
        }
    }

    private void updateNavigationButtons(int sectionIndex) {
        prevButton.setEnabled(currentItemIndex > 0);
        nextButton.setEnabled(currentItemIndex < cultureData[sectionIndex].length - 1);
    }

    private void toggleFavorite() {
        SharedPreferences prefs = getSharedPreferences("Favorites", MODE_PRIVATE);
        String key = currentSection + "_" + currentItemIndex;
        boolean isFavorite = prefs.getBoolean(key, false);

        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(key, !isFavorite);
        editor.apply();

        updateFavoriteButton();
    }

    private void updateFavoriteButton() {
        SharedPreferences prefs = getSharedPreferences("Favorites", MODE_PRIVATE);
        String key = currentSection + "_" + currentItemIndex;
        boolean isFavorite = prefs.getBoolean(key, false);

        favoriteButton.setText(isFavorite ? "★ В избранном" : "☆ В избранное");
    }
}