package com.example.gogo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button literatureButton = findViewById(R.id.literatureButton);
        Button musicButton = findViewById(R.id.musicButton);
        Button artButton = findViewById(R.id.artButton);
        Button architectureButton = findViewById(R.id.architectureButton);
        Button traditionsButton = findViewById(R.id.traditionsButton);
        Button favoritesButton = findViewById(R.id.favoritesButton);
        Button settingsButton = findViewById(R.id.settingsButton);

        literatureButton.setOnClickListener(v -> openCultureSection("literature"));
        musicButton.setOnClickListener(v -> openCultureSection("music"));
        artButton.setOnClickListener(v -> openCultureSection("art"));
        architectureButton.setOnClickListener(v -> openCultureSection("architecture"));
        traditionsButton.setOnClickListener(v -> openCultureSection("traditions"));

        favoritesButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, FavoritesActivity.class);
            startActivity(intent);
        });

        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        });
    }

    private void openCultureSection(String section) {
        Intent intent = new Intent(this, CultureSectionActivity.class);
        intent.putExtra("section", section);
        startActivity(intent);
    }
}