package com.example.gogo;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private RadioGroup languageRadioGroup;
    private RadioButton russianLanguage;
    private RadioButton englishLanguage;
    private CheckBox notificationsCheckBox;
    private CheckBox offlineModeCheckBox;
    private CheckBox highQualityImagesCheckBox;

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE);

        languageRadioGroup = findViewById(R.id.languageRadioGroup);
        russianLanguage = findViewById(R.id.russianLanguage);
        englishLanguage = findViewById(R.id.englishLanguage);
        notificationsCheckBox = findViewById(R.id.notificationsCheckBox);
        offlineModeCheckBox = findViewById(R.id.offlineModeCheckBox);
        highQualityImagesCheckBox = findViewById(R.id.highQualityImagesCheckBox);
        Button saveButton = findViewById(R.id.saveButton);
        Button cancelButton = findViewById(R.id.cancelButton);

        saveButton.setOnClickListener(v -> saveSettings());
        cancelButton.setOnClickListener(v -> finish());

        loadSettings();
    }

    private void loadSettings() {
        String language = sharedPreferences.getString("language", "ru");
        boolean notifications = sharedPreferences.getBoolean("notifications", true);
        boolean offlineMode = sharedPreferences.getBoolean("offlineMode", false);
        boolean highQuality = sharedPreferences.getBoolean("highQuality", true);

        if ("en".equals(language)) {
            englishLanguage.setChecked(true);
        } else {
            russianLanguage.setChecked(true);
        }

        notificationsCheckBox.setChecked(notifications);
        offlineModeCheckBox.setChecked(offlineMode);
        highQualityImagesCheckBox.setChecked(highQuality);
    }

    private void saveSettings() {
        SharedPreferences.Editor editor = sharedPreferences.edit();

        String language = russianLanguage.isChecked() ? "ru" : "en";

        editor.putString("language", language);
        editor.putBoolean("notifications", notificationsCheckBox.isChecked());
        editor.putBoolean("offlineMode", offlineModeCheckBox.isChecked());
        editor.putBoolean("highQuality", highQualityImagesCheckBox.isChecked());

        if (editor.commit()) {
            Toast.makeText(this, "Настройки сохранены", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Ошибка сохранения", Toast.LENGTH_SHORT).show();
        }
    }
}