package com.example.gogo;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class FavoritesActivity extends AppCompatActivity {

    private RecyclerView favoritesRecyclerView;
    private LinearLayout emptyStateLayout;
    private FavoritesAdapter favoritesAdapter;
    private List<FavoriteItem> favoriteItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        favoritesRecyclerView = findViewById(R.id.favoritesRecyclerView);
        emptyStateLayout = findViewById(R.id.emptyStateLayout);
        TextView emptyStateText = findViewById(R.id.emptyStateText);
        emptyStateText.setText("В избранном пока пусто\nДобавьте что-нибудь интересное!");

        favoriteItems = new ArrayList<>();
        favoritesAdapter = new FavoritesAdapter(favoriteItems);

        favoritesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        favoritesRecyclerView.setAdapter(favoritesAdapter);

        loadFavorites();
    }

    private void loadFavorites() {
        favoriteItems.add(new FavoriteItem("Александр Пушкин", "Величайший русский поэт", "Литература"));
        favoriteItems.add(new FavoriteItem("Пётр Чайковский", "Великий русский композитор", "Музыка"));

        favoritesAdapter.notifyDataSetChanged();
        updateEmptyState();
    }

    private void updateEmptyState() {
        if (favoriteItems.isEmpty()) {
            favoritesRecyclerView.setVisibility(View.GONE);
            emptyStateLayout.setVisibility(View.VISIBLE);
        } else {
            favoritesRecyclerView.setVisibility(View.VISIBLE);
            emptyStateLayout.setVisibility(View.GONE);
        }
    }

    public static class FavoriteItem {
        private String title;
        private String description;
        private String category;

        public FavoriteItem(String title, String description, String category) {
            this.title = title;
            this.description = description;
            this.category = category;
        }

        public String getTitle() { return title; }
        public String getDescription() { return description; }
        public String getCategory() { return category; }
    }
}