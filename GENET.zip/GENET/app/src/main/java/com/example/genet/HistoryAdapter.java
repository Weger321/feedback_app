package com.example.genet;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder> {

    private List<HistoryActivity.WorkoutSession> workoutSessions;

    public HistoryAdapter(List<HistoryActivity.WorkoutSession> workoutSessions) {
        this.workoutSessions = workoutSessions;
    }

    @NonNull
    @Override
    public HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_history, parent, false);
        return new HistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryViewHolder holder, int position) {
        HistoryActivity.WorkoutSession session = workoutSessions.get(position);
        holder.bind(session);
    }

    @Override
    public int getItemCount() {
        return workoutSessions.size();
    }

    static class HistoryViewHolder extends RecyclerView.ViewHolder {
        private TextView dateTextView;
        private TextView timeTextView;
        private TextView durationTextView;
        private TextView exercisesTextView;

        public HistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            timeTextView = itemView.findViewById(R.id.timeTextView);
            durationTextView = itemView.findViewById(R.id.durationTextView);
            exercisesTextView = itemView.findViewById(R.id.exercisesTextView);
        }

        public void bind(HistoryActivity.WorkoutSession session) {
            dateTextView.setText(session.getDate());
            timeTextView.setText(session.getTime());
            durationTextView.setText(session.getDuration() + " мин");
            exercisesTextView.setText(session.getExercisesCompleted() + " упр.");
        }
    }
}