package com.example.genet;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button startWorkoutButton;
    private Button historyButton;
    private Button settingsButton;
    private TextView statsTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupClickListeners();
        updateStats();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStats();
    }

    private void initializeViews() {
        startWorkoutButton = findViewById(R.id.startWorkoutButton);
        historyButton = findViewById(R.id.historyButton);
        settingsButton = findViewById(R.id.settingsButton);
        statsTextView = findViewById(R.id.statsTextView);
    }

    private void setupClickListeners() {
        startWorkoutButton.setOnClickListener(v -> startWorkout());
        historyButton.setOnClickListener(v -> showHistory());
        settingsButton.setOnClickListener(v -> showSettings());
    }

    private void startWorkout() {
        Intent intent = new Intent(this, WorkoutActivity.class);
        startActivity(intent);
    }

    private void showHistory() {
        Intent intent = new Intent(this, HistoryActivity.class);
        startActivity(intent);
    }

    private void showSettings() {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

    private void updateStats() {
        SharedPreferences historyPrefs = getSharedPreferences("WorkoutHistory", MODE_PRIVATE);
        List<HistoryActivity.WorkoutSession> sessions = HistoryActivity.getWorkoutHistory(historyPrefs);

        int totalWorkouts = sessions.size();
        int totalMinutes = 0;

        for (HistoryActivity.WorkoutSession session : sessions) {
            totalMinutes += session.getDuration();
        }

        String statsText = String.format("Всего тренировок: %d\nОбщее время: %d мин", totalWorkouts, totalMinutes);
        statsTextView.setText(statsText);
    }
}