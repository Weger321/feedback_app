package com.example.genet;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    // UI компоненты
    private RadioGroup difficultyRadioGroup;
    private RadioButton difficultyEasy;
    private RadioButton difficultyMedium;
    private RadioButton difficultyHard;
    private SeekBar workoutDurationSeekBar;
    private TextView durationValueTextView;
    private CheckBox autoStartCheckBox;
    private CheckBox voiceInstructionsCheckBox;
    private CheckBox vibrationCheckBox;
    private Button saveButton;
    private Button cancelButton;

    // Ключи для SharedPreferences
    private static final String PREFS_NAME = "WorkoutSettings";
    private static final String KEY_DIFFICULTY = "difficulty";
    private static final String KEY_DURATION = "duration";
    private static final String KEY_AUTO_START = "auto_start";
    private static final String KEY_VOICE_INSTRUCTIONS = "voice_instructions";
    private static final String KEY_VIBRATION = "vibration";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Инициализация SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        editor = sharedPreferences.edit();

        initializeViews();
        setupClickListeners();
        loadSettings();
    }

    private void initializeViews() {
        difficultyRadioGroup = findViewById(R.id.difficultyRadioGroup);
        difficultyEasy = findViewById(R.id.difficultyEasy);
        difficultyMedium = findViewById(R.id.difficultyMedium);
        difficultyHard = findViewById(R.id.difficultyHard);
        workoutDurationSeekBar = findViewById(R.id.workoutDurationSeekBar);
        durationValueTextView = findViewById(R.id.durationValueTextView);
        autoStartCheckBox = findViewById(R.id.autoStartCheckBox);
        voiceInstructionsCheckBox = findViewById(R.id.voiceInstructionsCheckBox);
        vibrationCheckBox = findViewById(R.id.vibrationCheckBox);
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);
    }

    private void setupClickListeners() {
        // Слушатель для SeekBar
        workoutDurationSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Минимальная продолжительность - 5 минут
                int minutes = progress + 5;
                durationValueTextView.setText(minutes + " мин");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Не используется
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Не используется
            }
        });

        // Кнопка сохранения
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
            }
        });

        // Кнопка отмены
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void loadSettings() {
        // Загрузка настроек из SharedPreferences
        int difficulty = sharedPreferences.getInt(KEY_DIFFICULTY, 1); // 0-легко, 1-средне, 2-сложно
        int duration = sharedPreferences.getInt(KEY_DURATION, 10); // в минутах
        boolean autoStart = sharedPreferences.getBoolean(KEY_AUTO_START, false);
        boolean voiceInstructions = sharedPreferences.getBoolean(KEY_VOICE_INSTRUCTIONS, false);
        boolean vibration = sharedPreferences.getBoolean(KEY_VIBRATION, true);

        // Установка значений в UI
        switch (difficulty) {
            case 0:
                difficultyEasy.setChecked(true);
                break;
            case 1:
                difficultyMedium.setChecked(true);
                break;
            case 2:
                difficultyHard.setChecked(true);
                break;
        }

        // Установка продолжительности (минимальная 5 минут)
        workoutDurationSeekBar.setProgress(duration - 5);
        durationValueTextView.setText(duration + " мин");

        autoStartCheckBox.setChecked(autoStart);
        voiceInstructionsCheckBox.setChecked(voiceInstructions);
        vibrationCheckBox.setChecked(vibration);
    }

    private void saveSettings() {
        // Получение значений из UI
        int difficulty = 1; // по умолчанию средняя
        int checkedId = difficultyRadioGroup.getCheckedRadioButtonId();
        if (checkedId == R.id.difficultyEasy) {
            difficulty = 0;
        } else if (checkedId == R.id.difficultyMedium) {
            difficulty = 1;
        } else if (checkedId == R.id.difficultyHard) {
            difficulty = 2;
        }

        int duration = workoutDurationSeekBar.getProgress() + 5; // минимальная 5 минут
        boolean autoStart = autoStartCheckBox.isChecked();
        boolean voiceInstructions = voiceInstructionsCheckBox.isChecked();
        boolean vibration = vibrationCheckBox.isChecked();

        // Сохранение в SharedPreferences
        editor.putInt(KEY_DIFFICULTY, difficulty);
        editor.putInt(KEY_DURATION, duration);
        editor.putBoolean(KEY_AUTO_START, autoStart);
        editor.putBoolean(KEY_VOICE_INSTRUCTIONS, voiceInstructions);
        editor.putBoolean(KEY_VIBRATION, vibration);

        if (editor.commit()) {
            Toast.makeText(this, "Настройки сохранены", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Ошибка сохранения", Toast.LENGTH_SHORT).show();
        }
    }

    // Метод для получения настроек из других активностей
    public static int getDifficulty(SharedPreferences prefs) {
        return prefs.getInt(KEY_DIFFICULTY, 1);
    }

    public static int getWorkoutDuration(SharedPreferences prefs) {
        return prefs.getInt(KEY_DURATION, 10);
    }

    public static boolean getAutoStartEnabled(SharedPreferences prefs) {
        return prefs.getBoolean(KEY_AUTO_START, false);
    }

    public static boolean getVoiceInstructionsEnabled(SharedPreferences prefs) {
        return prefs.getBoolean(KEY_VOICE_INSTRUCTIONS, false);
    }

    public static boolean getVibrationEnabled(SharedPreferences prefs) {
        return prefs.getBoolean(KEY_VIBRATION, true);
    }
}