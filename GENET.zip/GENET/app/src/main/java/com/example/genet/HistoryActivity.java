package com.example.genet;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.example.genet.R;

public class HistoryActivity extends AppCompatActivity {

    private RecyclerView historyRecyclerView;
    private LinearLayout emptyStateLayout;
    private TextView emptyStateText;
    private HistoryAdapter historyAdapter;
    private List<WorkoutSession> workoutSessions;
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "WorkoutHistory";
    private static final String KEY_HISTORY = "workout_history";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        initializeViews();
        setupRecyclerView();
        loadHistory();
    }

    private void initializeViews() {
        historyRecyclerView = findViewById(R.id.historyRecyclerView);
        emptyStateLayout = findViewById(R.id.emptyStateLayout);
        emptyStateText = findViewById(R.id.emptyStateText);

        // Установка текста для пустого состояния
        emptyStateText.setText("История тренировок пуста\nНачните первую тренировку!");
    }

    private void setupRecyclerView() {
        workoutSessions = new ArrayList<>();
        historyAdapter = new HistoryAdapter(workoutSessions);

        historyRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        historyRecyclerView.setAdapter(historyAdapter);
    }

    private void loadHistory() {
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String historyJson = sharedPreferences.getString(KEY_HISTORY, "");

        if (!historyJson.isEmpty()) {
            Gson gson = new Gson();
            Type type = new TypeToken<List<WorkoutSession>>() {}.getType();
            List<WorkoutSession> savedSessions = gson.fromJson(historyJson, type);

            if (savedSessions != null) {
                workoutSessions.clear();
                workoutSessions.addAll(savedSessions);
                historyAdapter.notifyDataSetChanged();
            }
        }

        updateEmptyState();
    }

    private void updateEmptyState() {
        if (workoutSessions.isEmpty()) {
            historyRecyclerView.setVisibility(View.GONE);
            emptyStateLayout.setVisibility(View.VISIBLE);
        } else {
            historyRecyclerView.setVisibility(View.VISIBLE);
            emptyStateLayout.setVisibility(View.GONE);
        }
    }

    // Метод для добавления новой тренировки в историю (вызывается из других активностей)
    public static void addWorkoutToHistory(SharedPreferences prefs, int duration, int exercisesCompleted) {
        WorkoutSession newSession = new WorkoutSession(duration, exercisesCompleted);
        List<WorkoutSession> sessions = getWorkoutHistory(prefs);

        sessions.add(0, newSession); // Добавляем в начало списка

        // Сохраняем только последние 50 тренировок
        if (sessions.size() > 50) {
            sessions = sessions.subList(0, 50);
        }

        Gson gson = new Gson();
        String historyJson = gson.toJson(sessions);

        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_HISTORY, historyJson);
        editor.apply();
    }

    // Метод для получения истории тренировок
    public static List<WorkoutSession> getWorkoutHistory(SharedPreferences prefs) {
        String historyJson = prefs.getString(KEY_HISTORY, "");

        if (historyJson.isEmpty()) {
            return new ArrayList<>();
        }

        Gson gson = new Gson();
        Type type = new TypeToken<List<WorkoutSession>>() {}.getType();
        List<WorkoutSession> sessions = gson.fromJson(historyJson, type);

        return sessions != null ? sessions : new ArrayList<>();
    }

    // Метод для очистки истории
    private void clearHistory() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(KEY_HISTORY);
        editor.apply();

        workoutSessions.clear();
        historyAdapter.notifyDataSetChanged();
        updateEmptyState();
    }

    // Внутренний класс для представления данных о тренировке
    public static class WorkoutSession {
        private String date;
        private int duration; // в минутах
        private int exercisesCompleted;
        private String time; // время тренировки

        public WorkoutSession(int duration, int exercisesCompleted) {
            this.date = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(new Date());
            this.time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
            this.duration = duration;
            this.exercisesCompleted = exercisesCompleted;
        }

        // Конструктор для Gson
        public WorkoutSession() {}

        public String getDate() {
            return date;
        }

        public int getDuration() {
            return duration;
        }

        public int getExercisesCompleted() {
            return exercisesCompleted;
        }

        public String getTime() {
            return time;
        }
    }
}