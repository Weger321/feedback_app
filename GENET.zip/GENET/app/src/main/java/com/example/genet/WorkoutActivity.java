package com.example.genet;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class WorkoutActivity extends AppCompatActivity {

    // UI компоненты
    private TextView exerciseNameTextView;
    private TextView exerciseDescriptionTextView;
    private TextView timerTextView;
    private TextView progressTextView;
    private ImageView exerciseImageView;
    private Button startPauseButton;
    private Button nextButton;
    private Button previousButton;
    private Button finishButton;
    private ProgressBar progressBar;

    // Данные упражнений
    private Exercise[] exercises = {
            new Exercise("Разминка", "Вращение головы, плеч, кистей", 30, R.drawable.warmup),
            new Exercise("Наклоны", "Наклоны вперед к ногам", 45, R.drawable.bending),
            new Exercise("Приседания", "Классические приседания", 60, R.drawable.squats),
            new Exercise("Отжимания", "Отжимания от пола", 45, R.drawable.pushups),
            new Exercise("Планка", "Удержание положения", 30, R.drawable.plank),
            new Exercise("Растяжка", "Растяжка всех групп мышц", 60, R.drawable.stretching)
    };

    // Таймер и состояние
    private CountDownTimer countDownTimer;
    private int currentExerciseIndex = 0;
    private long timeLeftInMillis;
    private boolean timerRunning = false;
    private int totalExercisesCompleted = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout);

        initializeViews();
        setupClickListeners();
        loadExercise(currentExerciseIndex);
    }

    private void initializeViews() {
        exerciseNameTextView = findViewById(R.id.exerciseNameTextView);
        exerciseDescriptionTextView = findViewById(R.id.exerciseDescriptionTextView);
        timerTextView = findViewById(R.id.timerTextView);
        progressTextView = findViewById(R.id.progressTextView);
        exerciseImageView = findViewById(R.id.exerciseImageView);
        startPauseButton = findViewById(R.id.startPauseButton);
        nextButton = findViewById(R.id.nextButton);
        previousButton = findViewById(R.id.previousButton);
        finishButton = findViewById(R.id.finishButton);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setupClickListeners() {
        startPauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleTimer();
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentExerciseIndex < exercises.length - 1) {
                    nextExercise();
                }
            }
        });

        previousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentExerciseIndex > 0) {
                    previousExercise();
                }
            }
        });

        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishWorkout();
            }
        });
    }

    private void loadExercise(int index) {
        Exercise exercise = exercises[index];

        exerciseNameTextView.setText(exercise.getName());
        exerciseDescriptionTextView.setText(exercise.getDescription());
        exerciseImageView.setImageResource(exercise.getImageResource());

        timeLeftInMillis = exercise.getDuration() * 1000;
        updateTimerText();
        updateProgress();

        // Сброс таймера
        if (timerRunning) {
            pauseTimer();
        }

        // Обновление состояния кнопок
        previousButton.setEnabled(index > 0);
        nextButton.setEnabled(index < exercises.length - 1);

        // Сброс цвета таймера
        timerTextView.setTextColor(ContextCompat.getColor(this, R.color.timer_color));
    }

    private void toggleTimer() {
        if (timerRunning) {
            pauseTimer();
        } else {
            startTimer();
        }
    }

    private void startTimer() {
        countDownTimer = new CountDownTimer(timeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                updateTimerText();
                updateProgress();

                // Изменение цвета при малом времени (менее 10 секунд)
                if (timeLeftInMillis < 10000) {
                    timerTextView.setTextColor(ContextCompat.getColor(WorkoutActivity.this, R.color.warning_color));
                }
            }

            @Override
            public void onFinish() {
                timeLeftInMillis = 0;
                timerRunning = false;
                updateTimerText();
                updateProgress();
                totalExercisesCompleted++;

                // Автоматический переход к следующему упражнению
                if (currentExerciseIndex < exercises.length - 1) {
                    nextExercise();
                } else {
                    finishWorkout();
                }
            }
        }.start();

        timerRunning = true;
        startPauseButton.setText("Пауза");
        startPauseButton.setBackgroundColor(ContextCompat.getColor(this, R.color.warning_color));
    }

    private void pauseTimer() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        timerRunning = false;
        startPauseButton.setText("Старт");
        startPauseButton.setBackgroundColor(ContextCompat.getColor(this, R.color.success_color));
    }

    private void nextExercise() {
        currentExerciseIndex++;
        loadExercise(currentExerciseIndex);
    }

    private void previousExercise() {
        currentExerciseIndex--;
        loadExercise(currentExerciseIndex);
    }

    private void updateTimerText() {
        int minutes = (int) (timeLeftInMillis / 1000) / 60;
        int seconds = (int) (timeLeftInMillis / 1000) % 60;

        String timeLeftFormatted = String.format("%02d:%02d", minutes, seconds);
        timerTextView.setText(timeLeftFormatted);
    }

    private void updateProgress() {
        // Прогресс текущего упражнения
        Exercise currentExercise = exercises[currentExerciseIndex];
        int totalTime = currentExercise.getDuration() * 1000;
        int progress = (int) ((totalTime - timeLeftInMillis) * 100 / totalTime);
        progressBar.setProgress(progress);

        // Общий прогресс тренировки
        int totalProgress = (currentExerciseIndex * 100 + progress) / exercises.length;
        progressTextView.setText(String.format("Прогресс: %d%%", totalProgress));
    }

    private void finishWorkout() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }

        // Сохранение тренировки в историю
        int totalDuration = calculateTotalDuration();
        SharedPreferences historyPrefs = getSharedPreferences("WorkoutHistory", MODE_PRIVATE);
        HistoryActivity.addWorkoutToHistory(historyPrefs, totalDuration, totalExercisesCompleted);

        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("workout_completed", true);
        startActivity(intent);
        finish();
    }

    private int calculateTotalDuration() {
        int total = 0;
        for (int i = 0; i <= currentExerciseIndex; i++) {
            total += exercises[i].getDuration();
        }
        return total / 60; // возвращаем в минутах
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }

    // Внутренний класс для упражнений
    private static class Exercise {
        private String name;
        private String description;
        private int duration; // в секундах
        private int imageResource;

        public Exercise(String name, String description, int duration, int imageResource) {
            this.name = name;
            this.description = description;
            this.duration = duration;
            this.imageResource = imageResource;
        }

        public String getName() {
            return name;
        }

        public String getDescription() {
            return description;
        }

        public int getDuration() {
            return duration;
        }

        public int getImageResource() {
            return imageResource;
        }
    }
}